from jmetal import algorithm, core, operator, problem
from jmetal.logger import configure_logging

configure_logging()

__all__ = ["core", "algorithm", "operator", "problem"]
__version__ = "1.5.7"
