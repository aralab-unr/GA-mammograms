from .singleobjective.tsp import TSP
from .singleobjective.unconstrained import OneMax, Sphere

__all__ = [
    "Srinivas",
    "Tanaka",
    "Kursawe",
    "Fonseca",
    "Schaffer",
    "Viennet2",
    "DTLZ1",
    "DTLZ2",
    "ZDT1",
    "ZDT2",
    "ZDT3",
    "ZDT4",
    "ZDT6",
    "LZ09_F2",
    "OneMax",
    "Sphere",
    "TSP",
]
